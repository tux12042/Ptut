function domaine_1() {
    document.getElementById("eco-citoyenneté").style.display = 'block';
    document.getElementById("dynamisation").style.display = 'none';
    document.getElementById("lien-inter-générationnel").style.display = 'none';
    document.getElementById("tourisme").style.display = 'none';
    document.getElementById("economie").style.display = 'none';
}

function domaine_2() {
    document.getElementById("eco-citoyenneté").style.display = 'none';
    document.getElementById("dynamisation").style.display = 'block';
    document.getElementById("lien-inter-générationnel").style.display = 'none';
    document.getElementById("tourisme").style.display = 'none';
    document.getElementById("economie").style.display = 'none';
}

function domaine_3() {
    document.getElementById("eco-citoyenneté").style.display = 'none';
    document.getElementById("dynamisation").style.display = 'none';
    document.getElementById("lien-inter-générationnel").style.display = 'block';
    document.getElementById("tourisme").style.display = 'none';
    document.getElementById("economie").style.display = 'none';
}

function domaine_4() {
    document.getElementById("eco-citoyenneté").style.display = 'none';
    document.getElementById("dynamisation").style.display = 'none';
    document.getElementById("lien-inter-générationnel").style.display = 'none';
    document.getElementById("tourisme").style.display = 'block';
    document.getElementById("economie").style.display = 'none';
}

function domaine_5() {
    document.getElementById("eco-citoyenneté").style.display = 'none';
    document.getElementById("dynamisation").style.display = 'none';
    document.getElementById("lien-inter-générationnel").style.display = 'none';
    document.getElementById("tourisme").style.display = 'none';
    document.getElementById("economie").style.display = 'block';
}